import sys
import boto3
import time

import sys
import boto3
import time

def revert_isolate_bucket(revert_log):
    print("Running revert_isolate_bucket().. ")
   
    return

def isolate_bucket(bucket_name,region):
    print("Running isolate_bucket().. ")

    s3 = boto3.resource('s3', region_name=region)
    bucket_acl = s3.BucketAcl(bucket_name)
    
    print (bucket_acl.owner)
    print (bucket_acl.grants)

    #response = bucket_acl.put(
    #AccessControlPolicy={
    #    'Owner' : bucket_acl.owner
    #    'Grants': '{}',
    #}
    #)
    
    print (bucket_acl.owner)
    print (bucket_acl.grants)

    revert_log = "ff"

    return revert_log


